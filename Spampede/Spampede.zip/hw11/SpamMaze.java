/*
 * class SpamMaze
 *
 * represents and handles the model for the Spampede applet
 */

// you might want this to pick a random cell for Spam
import java.lang.Math;
// you'll use this for your list of spam cells and pede cells
import java.util.LinkedList;
// you'll use the Queue interface to do your breadth first search
import java.util.Queue;

/* SpamMaze derives from (inherits from) Maze ...
 */
class SpamMaze extends Maze {
	// The data members representing the spam and the centipede
	public static final char NORTH = 'N';
	public static final char SOUTH = 'S';
	public static final char EAST = 'E';
	public static final char WEST = 'W';
	public static final char SEARCH = 'A';
	public static final char STOP = ' ';

	public static final int GAMEOVER = -1;
	public static final int ATESPAM = 1;
	public static final int ADVANCE = 0;

	// you may want other data members representing various
	// constants that are important in the Spampede application...
	// Avoid magic numbers (or constants!)
	
	// here are the LinkedLists to hold and represent the pede and the spam
	private LinkedList<MazeCell> spamCells;
	private LinkedList<MazeCell> pedeCells;

	/*
	 * a zero-argument constructor. This  calls the base class's
	 * zero-argument constructor (to create the Maze) and then it calls
	 *   this.resetPedeAndSpam() 
	 * in order to do additional initializion of the data members 
	 * that are part of only the SpamMaze class (see above).
	 */
	public SpamMaze() {
		super();
		this.resetPedeAndSpam();
	}

	/*
	 * Instead of making the default SpamMaze as used in the no-argument
	 * constructor, this constructor takes a 2D array of Strings and creates a
	 * Maze based upon that.
	 */
	public SpamMaze(String[] mazeStringInput) {
		super(mazeStringInput);
		this.resetPedeAndSpam();
	}
	
	/*
	 * special constructor for testing that does not reset pede and spam
	 */
	public SpamMaze(String[] mazeStringInput, int i){
		super(mazeStringInput);
	}

	/*
	 * Note: It's most flexible to delegate the set-up of the centipede and spam
	 * to other methods designed for that purpose: that is, you'll call
	 * resetPede and addSpam which you'll define below... .
	 * 
	 * The reason that it's nice to have that functionality separate is that,
	 * when the snake crashes, you'll be able to call those reset functions --
	 * you *won't* want to re-construct another SpamMaze!
	 */

	/* resetPedeAndSpam
	 * is a zero-input method that should remove all of the MazeCells from
	 * pedeCells (if any), reset their contents appropriately, and then
	 * initialize a new centipede in your game's starting position.
	 * 
	 * Note that the initial state for the DEFAULT game is that the pede
     * has two MazeCells:
     *     a MazeCell at row = 1 and column = 2 containing the head 
     *     a MazeCell at row = 1 and column = 1 containing the body
     *     
     * The initial spam amount is up to you, though you should make sure there
     * is at least some spam to go after! Later, you can decide to reset the
     * spam or to let it accumulate even through calls to this method.
	 */
	public void resetPedeAndSpam() {
		// check to see if there are any spam cells
		// no spam cells, construct empty linked list
		if(this.spamCells == null) {
			this.spamCells = new LinkedList<MazeCell>(); 
		}
		// yes spamCells, reset the cells and remove from list
		else {
			for(int i = 0; i < spamCells.size(); i++){
				spamCells.getFirst().setContents(' ');
				spamCells.removeFirst();
			}
		}
		// add a random spam
		this.addSpam();
		//check to see if there are any pedeCells
		// no pedeCells, construct empty Linked List
		if(this.pedeCells == null){
			this.pedeCells = new LinkedList<MazeCell>();
		}
		// yes pedeCells, reset the cells and remove them from the list
		else{
			for(int i = 0; i < pedeCells.size(); i++){
				pedeCells.getFirst().setContents(' ');
				pedeCells.removeFirst();
			}
		}
		// set the initial cells and put them in the list
		MazeCell head = this.getCell(1,2);
		head.setContents('H');
		MazeCell body = this.getCell(1, 1);
		body.setContents('B');
		this.pedeCells.addFirst(head);
		this.pedeCells.addLast(body);
		
		
		
		/*
		 * You might be worried -- how do I tell the applet that the snake is
		 * facing east? You won't need to do that here; rather, the Applet will
		 * start with its data member named dir assigned to SpamMaze.EAST. Every time the
		 * Spampede crashes, you'll send a message to the Applet to let it know:
		 * this is the return value from advancePede.
		 */
	}

	/*
	 * noSpam()
	 * 
	 * An optional helper method to check if there are no spam available.
	 */
	public boolean noSpam() {
		return this.spamCells.isEmpty();
	}

	/*
	 * addSpam()
	 * 
	 * adds one can of spam to the environment. You can choose the method used
	 * to add spam but the following properties are required:
	 * 
	 * 1. An inserted can of spam may not be placed anywhere on the current
	 * location of the centipede's body nor on a wall.
	 * 
	 * 2. The reference to the new can of spam must be inserted in the spamCells
	 * LinkedList.
	 * 
	 * You may wish to use random numbers to generate the locations of new spam
	 * cans. To do so, you can use a line similar to this:
	 * 
	 * int value = (int)(42*Math.random());
	 * 
	 * This line yields a random integer from 0 to 41 inclusive. It works
	 * because Math.random() is a random floating-point number from zero
	 * (inclusive) to one (exclusive): [0, 1). The multiplication scales that
	 * range and the cast to int rounds it down.
	 */
	
	public void addSpam() {
		MazeCell candidate;
		do {
			int rValue = (int)(this.getNumRows()*Math.random());
			int cValue = (int)(this.getNumColumns()*Math.random());
			candidate = this.getCell(rValue, cValue);
		} while (!candidate.isOpen());
		candidate.setContents('D');
		spamCells.addLast(candidate); 
	}


	/*
	 * removeSpam()
	 * removes one can of spam from the environment when it's time for the spam
	 * to disappear. 
	 * 
	 * Notice that this function will simply be called
	 * periodically in order to make the game more interesting. It will _not_ be
	 * called when the centipede consumes a can of spam. 
	 * 
	 * That event will be handled in the advancePede function described below. 
	 * You can choose your own method to remove spam, but the following property is required:
	 * When this function is called, a can of spam is eliminated from the LinkedList named
	 * this.spamCells. This can be done at random or (perhaps more reasonably) the
	 * oldest spam can in the list can be removed and handled appropriately...
	 */

	public void removeSpam() {
		MazeCell spamToRemove = spamCells.getFirst();
		spamToRemove.setContents(' ');
		spamCells.removeFirst();
	}

	/*
	 * advancePede(char direction)
	 * 
	 * this is the fundamental update method for the entire game! This is where
	 * the "smarts" go. In particular, a character indicating the direction to
	 * move is passed in. The characters 'N', 'S', 'E', 'W', 'A' should
	 * represent the directions north, south, east, west, and automatic
	 * ("automatic" will be described below).
	 */
	public int advancePede(char direction) {
		/*
		 * Based on the direction that is passed in, the pedeCells LinkedList is
		 * updated to have the centipede move in that direction. That is, the
		 * head advances and the tail retracts in the given direction. If the
		 * centipede's head moves to a MazeCell that contains a wall or another
		 * part of the centipede, the centipede dies, and the centipede should
		 * be reset to its initial state.
		 * 
		 * This function need not necessarily do the resetting.
		 * 
		 * Notice that this function returns an integer value (or you can change
		 * it to a char if you prefer). That value may be used to help with the
		 * resetting elsewhere in the program. This is described next... So what
		 * exactly is the return value? It is handy for this function to return
		 * an integer or some other data informing the Applet what happened... .
		 * For example, if there was a collision with a wall, the return value
		 * can let the Applet know this, so that the Applet can reset this.dir
		 * to EAST and make other changes it might need. For the moment, you
		 * might just return 0 (ADVANCE) here -- you can always come back to this later -
		 * when doing part 3 - to decide what you would like the function to return.
		 * 
		 * If the centipede's head lands on a can of spam, the centipede grows
		 * by one MazeCell. That is, when the centipede next moves, its head
		 * advances one square, but its tail does not retract. It's important that the
		 * can of spam just consumed be removed from this.spamCells! 
		 * 
		 * What command will be used to do this?
		 * Check out the remove command in the LinkedList class!
		 * 
		 * Finally, the automatic direction. If this function is passed in the
		 * value 'A' then we are in AI mode. That is, the spampede should
		 * navigate by itself, also heading for the nearest can of spam. To do
		 * this, it will call the multiBFS method that you wrote in Part 1.
		 * 
		 * multiBFS will return a reference to the MazeCell that the spampede
		 * should move to. The spampede will then be updated to move to that
		 * cell.
		 * 
		 * Note - you probably want to use the helper method getNextCell below.
		 */
		
		// for now, we will return that the pede will be advancing...
		MazeCell nextCell = this.getNextCell(direction);
		//eat spam
		if (nextCell.isSpam()) {
			pedeCells.getFirst().setContents('B');
			spamCells.remove(nextCell);
			pedeCells.addFirst(nextCell);
			pedeCells.getFirst().setContents('H');
			return SpamMaze.ATESPAM;
		}
		//whitespace
		else if (nextCell.isOpen()) {
			pedeCells.getLast().setContents(' ');
			pedeCells.removeLast();
			pedeCells.getFirst().setContents('B');
			pedeCells.addFirst(nextCell);
			pedeCells.getFirst().setContents('H');
		}
		//run into wall or yourself
		else if(nextCell.isBody() || nextCell.isWall()) {
			return SpamMaze.GAMEOVER;
		}
		return SpamMaze.ADVANCE;
	}

	/*
	 * getNextCell(char direction)
	 * 
	 * Helper method to get the next cell that the pede should enter. This will
	 * be based upon the direction the pede is facing. If direction is
	 * SpamMaze.SEARCH then this will be the next MazeCell on the path to the
	 * closest spam.
	 */
	
	public MazeCell getNextCell(char direction) {
		MazeCell head = pedeCells.getFirst();
		if (direction == NORTH) {
			return this.getNorthNeighbor(head);
		}
		if (direction == SOUTH) {
			return this.getSouthNeighbor(head);
		}
		if (direction == EAST) {
			return this.getEastNeighbor(head);
		}
		if (direction == WEST) {
			return this.getWestNeighbor(head);
		}
		if (direction == SEARCH){
			return this.multiBFS(head);
		}
		return null;
	}

	/*
	 * reversePede()
	 * 
	 * A helper method to reverse the pede when someone presses 'r'
	 * 
	 * this method reverses the centipede so that it has the opposite
	 * orientation and moves in the appropriate "opposite direction". Note that
	 * if the centipede was previously moving west, it is not necessarily going
	 * to move east upon reversal. Instead, the new direction is the opposite of
	 * the direction of the tail of the centipede. That is, if the last two
	 * cells of the centipede's body indicate that the centipede is moving
	 * north, then the new direction for the reversed centipede will be south.
	 * In addition to modifying the pedeCells linked list to perform the
	 * reversal, this function returns the new direction.
	 * 
	 * There are a number of ways to handle this.
	 * 
	 * For one, you could you could take all of the cells off pedeCells and
	 * create a brand new LinkedList (in the newly-correct order) and use that
	 * as pedeCells going forward. A more difficult method is to not change
	 * pedeCells at all, but simply remember which side you're treating as the
	 * head and which side as the tail. Although it is computationally less
	 * intensive running the game if you add logic to treat either side of
	 * pedeCells as the head, we strongly encourage you to start with the
	 * strategy of creating a new LinkedList with the correct order. An
	 * important rule in software engineering is to optimize as late in the
	 * process as possible! First - just get something working! It may turn out
	 * that there is something else that is much more important to spend your
	 * optimizing time on.
	 */
	
	public char reversePede() {
		//start by finding the tail, which is last
		int pedeLength = pedeCells.size();
		MazeCell tail = pedeCells.getLast();
		int tailCol = tail.getCol();
		int tailRow = tail.getRow();
		//find the direction the tail is going by looking at the cell right 
		// before it
		MazeCell tailFront = pedeCells.get(pedeLength - 2);
		int tailFrontCol = tailFront.getCol();
		int tailFrontRow = tailFront.getRow();
		char dir;
		
		// same col, going north or south
		if(tailCol == tailFrontCol){
			//going south
			if (tailRow < tailFrontRow){
				dir = NORTH;
			}
			else {
				dir = SOUTH;
			}
		}
		// same row, going east or west
		else{
			// going east
			if (tailCol < tailFrontCol){
				dir = WEST;
			}
			else {
				dir = EAST;
			}
		}
		// set tail to head and head to tail
		tail.setContents('H');
		pedeCells.getFirst().setContents('B');
		// take out all cells and put them in a new linked list in reverse order
		LinkedList<MazeCell> newPedeCells = new LinkedList<MazeCell>();
		for(int i = 0; i < pedeLength; i++) {
			newPedeCells.addLast(pedeCells.get(pedeLength -i -1));
		}
		this.pedeCells = newPedeCells;
		return dir;
	}

	/*
	 * method: multiBFS
	 * 
	 * input: a starting cell and a char to seek
	 * 
	 * output: the maze cell that is DIRECTLY NEXT TO START and is the NEXT
	 * MazeCell ALONG the path to the nearest destination (spam)
	 * 
	 * You should print the path found the goal -- or a message saying
	 * there is no path to a goal. BE SURE TO CLEAR _EVERYTHING_ OUT of the 
	 * MazeCells before returning...
	 * 
	 * if there is no path, this method should return a randomly-chosen open
	 * MazeCell that is NEXT TO START
	 * 
	 * if there is no open MazeCell that is NEXT TO START, this method should
	 * return any MazeCell that is next to start (and it will crash)
	 */
	// you may want to write some helper methods along the way!
	public MazeCell multiBFS(MazeCell start) {
		this.clearFlags();
		Queue<MazeCell> cellsToVisit = new LinkedList<MazeCell>();
		cellsToVisit.add(start);
		MazeCell current = start;
		current.visit();
		//while queue is not empty
		while(cellsToVisit.peek() != null && !cellsToVisit.peek().isSpam()){
		// remove first element, check it, add children, mark parent for children	
			current = cellsToVisit.remove();
			MazeCell[] neighbors = this.getNeighbors(current);
			for(int i = 0; i<4; i++) {
				if(!neighbors[i].getVisited() && neighbors[i].isOpen()){
					cellsToVisit.add(neighbors[i]);
					neighbors[i].setParent(current);
					neighbors[i].visit();
				}
			}
		}
		// no path to spam -> print, use randomNeighbor for next cell.
		if(cellsToVisit.peek() == null) {
			System.out.println("No path to a SPAM was found. :'(");
			return this.getRandomNeighboringCell(start);
		}
		// check to see if we found spam or failed to find path to spam
		// found spam -> backtrack to find path and print
		else {
			System.out.println("The path found the SPAM!");
			MazeCell present = cellsToVisit.peek();
			while(present.getParent() != start){
				present = present.getParent();
			}
			return present;
		}
	}
	
	
	/*
	 * clearFlags() is a helper method for multiBFS, it resets the visited and 
	 * parent of each cell
	 * 
	 */
	
	public void clearFlags() {
		for(int r = 0; r < this.getNumRows(); r++){
			for(int c = 0; c < this.getNumColumns(); c++) {
				this.getCell(r, c).resetParent();
				this.getCell(r, c).resetVisited();
			}
		}
	}
	
	/*
	 * main! for testing things out informally
	 */
	public static void main(String[] args) { // same as Maze.main
		SpamMaze SM = new SpamMaze();
		System.out.println("SM is\n" + SM);
	}

}
