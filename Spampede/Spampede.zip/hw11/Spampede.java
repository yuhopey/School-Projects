/*
 * Spampede.java
 * 
 * Extends SpampedeBase, which you don't need to modify. 
 * 
 */
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.LinkedList;

public class Spampede extends SpampedeBase {

	private SpamMaze theMaze; // the model for our Spampede game
	private char dir; // the direction we're moving now...
	private Color currentColor; // This is for the big square
	private static final int SIZE_OF_CELLS = 10;

	
	/*
	 * init() is an initializer where everything starts...
	 */
	public void init() {
		System.out.println("Running init...");
		super.init();
		this.drawEnvironment(); // draw the gameboard, currently
		this.repaint(); // re-render everything to the screen
		// you can add other *one-time* intro items here
		// otherwise, you should use reset instead
	}
	
	/* Each time you start a new game, you will want to reset the
	 * internal representation of the game. Here's a good place to do it!
	 * Remember, the applet will be initialized just once, ( init() )
	 * but you may play the game many times within the applet ( reset() )
	 */
	void reset() {
		System.out.println("Running reset...");
		this.clear();
		this.theMaze = new SpamMaze(); // important! This is the "world"
		this.dir = SpamMaze.EAST;      // also important! This is the pede's heading...
		this.message = "Welcome to Spampede! (version 0.47)"; // Welcome, Sage ones...
		this.currentColor = Color.red;  // other data members getting initialized...
		
		if (audioSpam != null) audioSpam.play();  // Example of playing an audioclip
	}

	/*
	 * cycle()
	 * 
	 * Things you want to happen at each update step should be placed in this
	 * method. It's called from run() in SpampedeBase.
	 */
	void cycle() {
		this.updateCentipede(); // update the Pede
		this.updateSpam(); // update the list of Spam
		this.drawEnvironment(); // draw the maze
		this.displayMessage(); // Optional screen message...
		this.repaint();  // make the new display visible! (repaint is in the Component base class) 

		this.cycleNum++; // a variable to keep track of how many cycles have elapsed.
		if (this.cycleNum % 50 == 0) this.currentColor = Color.red; 
	}

	/*
	 * updateCentipede()
	 * 
	 * You should use this method to move the centipede one square Also, this
	 * method can check if the centipede runs into a can of spam, a wall,
	 * itself, etc. and act appropriately.
	 */
	
	void updateCentipede() {
		// you'll call theMaze.advancePede(this.dir) here!
		// based upon what advancePede returns (SpamMaze.ADVANCE, SpamMaze.ATESPAM,
		// or SpamMaze.GAMEOVER) you can choose different gameplay results
		int gameMode = theMaze.advancePede(this.dir);
		if (gameMode == SpamMaze.GAMEOVER){
			System.out.println("Game Over! Restart!");
			this.reset();
			}
		else if (gameMode == SpamMaze.ATESPAM){
			theMaze.addSpam();
		}
	}

	/*
	 * updateSpam()
	 * 
	 * You might use this method to add/delete spam cans periodically
	 */
	void updateSpam() {
		if (this.cycleNum % 500 == 0) {
			theMaze.removeSpam();
			theMaze.addSpam();
		}
		// you'll call theMaze.addSpam() here!
		;
	}
	
	/*
	 * A method to clear the applet's drawing area
	 * this.g is a Graphics object, holding the drawing routines:
	 * docs.oracle.com/javase/7/docs/api/java/awt/Graphics.html
	 */
	void clear() {
		this.g.setColor(BGCOLOR);
		this.g.fillRect(0, 0, this.getSize().width, this.getSize().height);
		this.g.setColor(Color.blue);
		int offset = 2;
		this.g.drawRect(offset, 
						offset, 
						this.getSize().width - 2*offset, 
						GAMEBOARDHEIGHT - 2*offset);
	}

	/*
	 * drawEnvironment()
	 * 
	 * This is where you will draw your 2D array of colored squares 
	 * Notice that all drawing occurs in the off-screen buffer "image". 
	 * The drawing commands themselves are held in the Graphics g.
	 * 
	 * repaint() copies the image to the screen ("double-buffering")
	 */
	void drawEnvironment() {
		this.clear(); 
		// use the variable Spampede.SIZE_OF_CELLS for the square size
		int SZ = Spampede.SIZE_OF_CELLS;   
		
		// some example calls
		// demonstrates the drawing of an image...
		
		//nested for loops representing a 10x10 array
		// offset to make sure we draw in the center-ish
		int centerC = 300 - (theMaze.getNumColumns()/2)*SZ;
		int centerR = 300 - (theMaze.getNumRows()/2)*SZ;
		
		for(int c = 0; c < theMaze.getNumColumns(); c++){
			for(int r = 0; r < theMaze.getNumRows(); r++){
				g.setColor(Spampede.getColor(theMaze.getCell(r,c)));
				g.fillRect(c*SZ + centerC, r*SZ + centerR, SZ, SZ);
			}
		}
		this.displayMessage();
	}

	/*
	 * ** Optional ** getColor(MazeCell cell)
	 * 
	 * You might use this method to determine what color a cell is based upon
	 * whether isSpam(), isOpen(), isHead(), or isBody() returns true
	 */
	private static Color getColor(MazeCell cell) {
		if (cell.isWall()) {
			return Color.blue;
		} else if (cell.isSpam()) {
			return Color.ORANGE;
		} else if (cell.isOpen()) {
			return Color.WHITE;
		} else if (cell.isHead()) {
			return Color.BLACK;
		} else if (cell.isBody()) {
			return Color.GREEN;
		} else {
			return Color.GRAY;
		}
	}

	/*
	 * You might use this method to draw a status String on the screen
	 */
	void displayMessage() {
		g.setColor(Color.blue);
		g.drawString(message, STRINGX, STRINGY);
	}

	/*
	 * keyPressed
	 * 
	 * This method will be called by the GUI when a key is pressed.
	 * 
	 * The method should update the direction of the pede and/or switch the
	 * direction of the pede ('r') or turn on AI mode ('a').
	 */
	public void keyPressed(KeyEvent evt) {

		// 'i' : turn north
		// 'j' : turn west
		// 'l' : turn east
		// 'k' : turn south
		// ' ' : should stay in place...
		// 'r' : should reverse the entire pede (and recompute the correct direction)
		// 'a' : go into autonomous, spam-seeking mode ("AI")

		// the code below provides examples of responding to key presses.
		// you might also want to read about Java switch/case statements:
		// http://docs.oracle.com/javase/tutorial/java/nutsandbolts/switch.html
		char key = evt.getKeyChar();
		if (key == 'i'){
			this.dir = SpamMaze.NORTH;
		}
		else if (key == 'j') {
			this.dir = SpamMaze.WEST;
		}
		else if (key == 'l') {
			this.dir = SpamMaze.EAST;
		}
		else if (key == 'k') {
			this.dir = SpamMaze.SOUTH;
		}
		else if (key == 'r') {
			this.dir = theMaze.reversePede();
		}

		else if (key == 'a') {
			this.dir = SpamMaze.SEARCH;
		}

		switch (evt.getKeyChar()) { // method returning the key pressed
		case '0':
		case '1':
			message = "You pressed the BIT " + evt.getKeyChar();
		case 'b':
			currentColor = Color.blue;
			break;
		case 'c':
			if (audioCrunch != null) audioCrunch.play();
		default:
			currentColor = Color.green;
			message = "You pressed the char " + evt.getKeyChar();
			break;
		}
	}

	// not used - a variable added to remove a Java warning:
	private static final long serialVersionUID = 1L;

}
