README FILE 

hw 11, cs60, Spring 2014

Date: Dec.9 2014

Name(s) of programmers: cs60bv



Please complete the template below, 
replacing the text between 
the ** symbols with your own text.

[1] Parts of the project completed/not completed:

   ** 
      I completed all the required portions of this assignment, but 
      did not do any of the extra credit.
   **

[2] Known bugs:  

   ** 
      The way that my SpamMaze constructor was written called 
      resetSpamAndPede(), which would alter the maze passed in 
      for testing and introduce an element of randomness which made testing
      impossible.
      To solve this, I created another constructor specifically for testing
      that did not alter the maze passed in.
   **

[3] Extra features that were added:

   ** 
      None at the moment.
   ** 

[4] (Optional) Comments about this project:

	**
      The provided tests were poorly written and many people had trouble understanding
      what was going on.
   ** 


