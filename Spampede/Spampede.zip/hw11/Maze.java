import java.util.Vector;

/*
 * This is the base maze class that handles constructing a 2D array
 * of MazeCells. Objects of type Maze can answer basic questions about
 * the content of the Maze.
 */
public class Maze {
	/*
	 * data member for the Maze class... a 2d rectangular array of MazeCells
	 */
	private MazeCell[][] mazeCells2D; // this is the maze!

	// To change the walls etc. in your maze, modify the following String[]
	public static final String[] mazeStrings = {
			"**************************************************",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                       **                       *",
			"*                       **                       *",
			"*                       **                       *",
			"*                       **                       *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"*                                                *",
			"**************************************************" };

	/*
	 * zero-argument constructor
	 */
	public Maze() {
		this(mazeStrings);
	}

	/*
	 * constructor that takes an array of strings as input
	 */
	public Maze(String[] mazeStrings) {
		int HEIGHT = mazeStrings.length;
		int WIDTH = mazeStrings[0].length();
		// solution 
		this.mazeCells2D = new MazeCell[HEIGHT][WIDTH];
		for (int r=0 ; r<HEIGHT ; ++r) {
			for (int c=0 ; c<WIDTH ; ++c) {
				char ch = mazeStrings[r].charAt(c);
				this.mazeCells2D[r][c] = new MazeCell(r,c,ch);
			}
		}
		// end solution
	}

	/*
	 * Get basic information about the grid of MazeCells
	 */
	// get the height (rows)
	public int getNumRows() {
		return this.mazeCells2D.length;
	}

	// get the width (columns)
	public int getNumColumns() {
		return this.mazeCells2D[0].length;
	}


	/*
	 * getCell(int row, int col)
	 * 
	 * Returns the MazeCell at that index.
	 */
	public MazeCell getCell(int r, int c) {
		if (r >= this.getNumRows() || c >= this.getNumColumns() || r < 0
				|| c < 0) {
			System.err.println("Trying to access cell outside of the Maze:");
			System.err.println("row: " + r + " col: " + c);
			System.exit(0);
		}
		return this.mazeCells2D[r][c];
	}

	/*
	 * Methods to get cells around a particular cell.
	 * Suggestion:
	 *   First, use cell.getRow and other capabilities
	 *   to get the row and col of the input cell
	 *   Then, determine _which_ cell from
	 *   this.mazeCells2D you want to return!
	 *
	 * Helpful:
	 *   We will not call this at the edge of the maze,
	 *   so you *don't* need to check that the neighbor
	 *   is out of bounds!
	 */
	
	public MazeCell getNorthNeighbor(MazeCell cell) {
		int myRow = cell.getRow();
		int myCol = cell.getCol();
		return this.mazeCells2D[myRow-1][myCol];
	}

	
	public MazeCell getSouthNeighbor(MazeCell cell) {
		int myRow = cell.getRow();
		int myCol = cell.getCol();
		return this.mazeCells2D[myRow+1][myCol];
	}

	
	public MazeCell getEastNeighbor(MazeCell cell) {
		int myRow = cell.getRow();
		int myCol = cell.getCol();
		return this.mazeCells2D[myRow][myCol+1];
	}

	
	public MazeCell getWestNeighbor(MazeCell cell) {
		int myRow = cell.getRow();
		int myCol = cell.getCol();
		return this.mazeCells2D[myRow][myCol-1];
	}

	
	/*
	 * getNeighbors(MazeCells center)
	 * 
	 * returns an array of MazeCells that surround the MazeCell center. The
	 * array it returns will typically be of length four and contain references
	 * to the MazeCells in NEWS order:
	 *   North, then East, then West, then South...
	 * 
	 * We will not call this method on cells at the edge of the Maze! Otherwise,
	 * you should, here, describe the behavior of this method if not all
	 * four neighbors are within the maze.
	 */
	
	// fill in the body of this method!
	public MazeCell[] getNeighbors(MazeCell center) {
		MazeCell[] neighbors = new MazeCell[4];
		neighbors[0] = this.getNorthNeighbor(center);
		neighbors[1] = this.getEastNeighbor(center);
		neighbors[2] = this.getWestNeighbor(center);
		neighbors[3] = this.getSouthNeighbor(center);
		return neighbors;
	}
	
	/*
	 * getRandomOpenNeighboringCell (MazeCell center)
	 * 
	 * @return an random open MazeCell around the start OR, if all
	 *  have contents other than SPAM or empty space, return the north cell
	 *
	 * Want a random integer in {0,1,2,3}?  
	 * Use int i = (int)(4*Math.random());
	 *
	 * There are a couple of possible approaches here:
	 *   2-loop approach:  run a loop to see if they're ALL non-open
	 *                     if some _are_ open, then choose one at random
	 *
	 *   1-loop approach:  run a loop 100 times to see if a random
	 *                     neighbor is open; if it never finds one, return north
	 *                     key: (0.25 ** 100) is _very_ small!
	 */
	
	public MazeCell getRandomNeighboringCell(MazeCell center) {
		Vector<MazeCell> pool = new Vector<MazeCell>(4);
		if (this.getEastNeighbor(center).isOpen()) {
			pool.add(this.getEastNeighbor(center));
		}
		if (this.getWestNeighbor(center).isOpen()){
			pool.add(this.getWestNeighbor(center));
		}
		if(this.getNorthNeighbor(center).isOpen()){
			pool.add(this.getNorthNeighbor(center));
		}
		if(this.getSouthNeighbor(center).isOpen()){
			pool.add(this.getSouthNeighbor(center));
		}
		if (pool.size() == 0) {
			return this.getNorthNeighbor(center);
		}
		else {
			int i = (int)(pool.size()*Math.random());
			return pool.elementAt(i);
		}
	}

	/*
	 * toString()
	 * 
	 * toString converts a maze to a string for printing
	 * Please don't change this -- we use it for testing!
	 */
	public String toString() {
		String result = "\n";
		for (int r = 0; r < this.getNumRows(); r++) {
			for (int c = 0; c < this.getNumColumns(); c++) {
				MazeCell cell = this.getCell(r, c);
				result += cell.getContents();
			}
			result += "\n";
		}
		result += "\n";
		return result;
	}
	
	/*
	 * main! for one introductory test
	 *       and trying things out on your own...
	 */
	public static void main(String[] args) {
		Maze M = new Maze();
		System.out.println("M is\n" + M);
	}
}
