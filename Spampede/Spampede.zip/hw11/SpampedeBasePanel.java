/*
 * You don't need to modify this file. 
 */
import javax.swing.JPanel;
import java.awt.Image;
import java.awt.Graphics;

//a panel that contains an image
public class SpampedeBasePanel extends JPanel{

	/**
	 * wrapper for the panel containing the image...
	 */

	//The image that this panel draws
	Image myImage;

	public SpampedeBasePanel(Image me)
	{
		myImage = me;

		//Makes the panel the same size as the image
		setPreferredSize(new java.awt.Dimension(me.getWidth(null),
												me.getHeight(null)));
	}

	// this overrides the paint method to draw the image on the panel
	public void paint(Graphics g)
	{
		g.drawImage(myImage, 0, 0, null);
	}
	// added to avoid a warning - Not used!
	private static final long serialVersionUID = 1L;
}
