import junit.framework.TestCase;

public class SpamMazeTest extends TestCase 
{
	// TODO - Assignment - add 9 more tests for multiBFS functionality
	// see the description for what those 9 should test
	public void test_multiBFS_1() {
		String[] mazeStr = { "******", "*S  D*", "******" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 1);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 2);
	}

	public void test_multiBFS_2() {
		String[] mazeStr = { "******", "*S   *", "******" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 1);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 2);
	}
	// 1. directly above
	public void test_multiBFS_3() {
		String[] mazeStr = { "******", "*D    *", "*S   *", "******" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(2, 1);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 1);
	}
	// 2. directly below
	public void test_multiBFS_4() {
		String[] mazeStr = { "******", "*S   *", "*D   *", "******" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 1);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 2);
		assertTrue(m.getCol() == 1);
	}
	// 3. directly right
	public void test_multiBFS_5() {
		String[] mazeStr = { "******", "*DS   *", "*    *", "******" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 2);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 1);
	}
	// 4. directly left
	public void test_multiBFS_6() {
		String[] mazeStr = { "******", "* SD  *", "*    *", "******" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 2);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 3);
	}
	// 5. no spam
	public void test_multiBFS_7() {
		String[] mazeStr = { "***", "*S*", "* *", "***" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 1);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 2);
		assertTrue(m.getCol() == 1);
	}
	// 6. no open spaces
	public void test_multiBFS_8() {
		String[] mazeStr = { "***", "*S*", "***", "***" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 1);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 0);
		assertTrue(m.getCol() == 1);
	}
	// 7. other characters next to start
	public void test_multiBFS_9() {
		String[] mazeStr = { "******", "*WSD  *", "*    *", "******" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 2);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 3);
	}
	// 8. multiple destinations on board
	public void test_multiBFS_10() {
		String[] mazeStr = { "******", "* SD  *", "*   D*", "******" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		MazeCell start = m1.getCell(1, 2);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 3);
	}
	// 9. The destination 'D' is at least 5 spaces away and
	// there are obstacles that requires traversing at least
	// one space in all four directions
	public void test_multiBFS_11() {
		String[] mazeStr = { "**********", "*S ***D  *", "** ****  *", 
				"*        *", "******** *", "**********" };
		SpamMaze m1 = new SpamMaze(mazeStr, 1);
		System.out.println(m1);
		MazeCell start = m1.getCell(1, 1);
		MazeCell m = m1.multiBFS(start);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 2);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 2);
		assertTrue(m.getCol() == 2);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 3);
		assertTrue(m.getCol() == 2);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 3);
		assertTrue(m.getCol() == 3);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 3);
		assertTrue(m.getCol() == 4);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 3);
		assertTrue(m.getCol() == 5);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 3);
		assertTrue(m.getCol() == 6);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 3);
		assertTrue(m.getCol() == 7);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 2);
		assertTrue(m.getCol() == 7);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 7);
		m = m1.multiBFS(m);
		assertTrue(m.getRow() == 1);
		assertTrue(m.getCol() == 6);
	}
}

