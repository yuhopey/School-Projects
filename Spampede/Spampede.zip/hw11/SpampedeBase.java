/*
 * SpampedeBase.java
 * 
 * To handle the buttons, menus, and display. 
 * 
 * You do not need to modify this file.
 * 
 */

import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.net.URL;


/*
 * Spampede is an example using both inheritance and interfaces
 */
public abstract class SpampedeBase extends JApplet implements ActionListener,
		KeyListener, Runnable {

	/**
	 * the data members in the base class for Spampede
	 */
	private static final long serialVersionUID = 1L;
	Image image; // off-screen buffer
	Graphics g; // that buffer's graphical tools

	int sleepTime = 30; // 30 milliseconds between updates
	int cycleNum; // number of update cycles so far

	String message; // A String that will be printed on screen

	// DEFINE CONSTANTS FOR YOUR PROGRAM HERE TO AVOID MAGIC VALUES!
	public static final int STRINGX = 10;
	public static final int STRINGY = 485;
	public static final int GAMEBOARDHEIGHT = 490; // Recommended values:
	// 490 with both menu bar and buttons
	// 525 with only the menu bar
	// 515 with only buttons
	public static final Color BGCOLOR = Color.white;

	// BELOW ARE DEFINITIONS OF BUTTONS AND MENU ITEMS WHICH WILL APPEAR
	private JButton newGameButton;
	private JButton pauseButton;
	private JButton startButton;

	private JMenu gameMenu;
	private JMenuItem newGameItem;
	private JMenuItem pauseItem;
	private JMenuItem startItem;

	// Here are other data members you might like to use (optional)...
	AudioClip audioSpam; // This is for playing a sound
	AudioClip audioCrunch; // This is for playing a sound
	Image imageSpam; // This is for loading an image

	// Initialize the applet.
	// This is called each time the page is reloaded.
	public void init() {
		// you may want other game-based set up to be in reset(), so that it
		// will be
		// redone each time the spampede crashes...

		this.addKeyListener(this); // listen for key events
		this.setLayout(new BorderLayout()); // set up layout on the form

		// beginning of button code
		// add a panel for buttons
		JPanel buttonPane = new JPanel(new FlowLayout());
		buttonPane.setBackground(BGCOLOR);
		this.add(buttonPane, BorderLayout.PAGE_START);

		this.newGameButton = new JButton("New Game"); // the text in the button
		this.newGameButton.addActionListener(this); // watch for button presses
		this.newGameButton.addKeyListener(this); // listen for key presses here
		buttonPane.add(this.newGameButton); // add button to the panel

		this.pauseButton = new JButton("Pause"); // a second button
		this.pauseButton.addActionListener(this);
		this.pauseButton.addKeyListener(this);
		buttonPane.add(this.pauseButton);

		this.startButton = new JButton("Start"); // a third button
		this.startButton.addActionListener(this);
		this.startButton.addKeyListener(this);
		buttonPane.add(this.startButton);
		// end of button code

		// beginning of menu bar code
		// Set up the menu bar
		JMenuBar menuBar = new JMenuBar();
		this.setJMenuBar(menuBar);

		// add a menu to contain items
		this.gameMenu = new JMenu("Game"); // The menu name
		menuBar.add(gameMenu); // Add the menu to the menu bar

		this.newGameItem = new JMenuItem("New Game"); // the text in the menu
														// item
		this.newGameItem.addActionListener(this); // Watch for button presses
		this.newGameItem.addKeyListener(this); // Listen for key presses here
		this.gameMenu.add(this.newGameItem); // Add the item to the menu

		this.pauseItem = new JMenuItem("Pause"); // A second menu item
		this.pauseItem.addActionListener(this);
		this.pauseItem.addKeyListener(this);
		this.gameMenu.add(this.pauseItem);

		this.startItem = new JMenuItem("Start"); // A third menu item
		this.startItem.addActionListener(this);
		this.startItem.addKeyListener(this);
		this.gameMenu.add(this.startItem);
		// end of menu bar code

		// If you choose not to use either menus or buttons, comment out the
		// related code, and adjust GAMEBOARDHEIGHT to account for the increased
		// amount of space available to the game board

		// Sets up the back (off-screen) buffer for drawing, named image
		this.image = this.createImage(this.getSize().width, GAMEBOARDHEIGHT);
		this.g = this.image.getGraphics(); // g holds the drawing routines
		this.reset(); // Set up the game internals!

		// add a central panel which holds the image buffer (the game board)
		this.add(new SpampedeBasePanel(image), BorderLayout.CENTER);

		// This is an example of loading in an image and a sound file.
		// You can play with this if you like, but it's not required.
		// So, you can also just comment it out (perhaps until later...)
		try {
			URL url = this.getCodeBase();
			this.audioSpam = this.getAudioClip(url, "Spam.au");
			this.audioCrunch = this.getAudioClip(url, "crunch.au");
			this.imageSpam = this.getImage(url, "spam.gif");
			System.out.println("successful loading of audio/images!");
		} catch (Exception e) {
			System.out.println("problem loading audio/images!");
			this.audioSpam = null;
			this.audioCrunch = null;
			this.imageSpam = null;
		}

	}

	/*
	 * the method that handles button-presses
	 */
	public void actionPerformed(ActionEvent evt) {
		Object source = evt.getSource();

		if (source == this.newGameButton || source == this.newGameItem){
			this.reset();
		}
		if (source == this.pauseButton || source == this.pauseItem){
			this.pause();
		}
		if (source == this.startButton || source == this.startItem){
			this.go();
		}
		this.requestFocus(); // makes sure the Applet keeps keyboard focus
	}

	public void keyReleased(KeyEvent evt) {
		// Not used at the moment
	}

	public void keyTyped(KeyEvent evt) {
		// Not used at the moment
	}
	
	/*
	 * Methods that *must* be overridden in Spampede in order to run
	 */
	
	public abstract void keyPressed(KeyEvent evt);
	abstract void cycle();
	abstract void drawEnvironment();
	abstract void reset();


	/* This is the end of the event-handling part of SpampedeBase */
	
	
	/* Here is the thread-handling part of SpampedeBase... */

	/*
	 * The following methods and data members are used to implement the Runnable
	 * interface and to support pausing and resuming the applet.
	 */
	Thread thread; // the thread controlling the updates
	boolean threadSuspended; // whether or not the thread is suspended
	boolean running; // whether or not the thread is stopped

	/*
	 * This is the method that calls the "cycle()" method every so often (every
	 * sleepTime milliseconds).
	 */
	public void run() {
		while (this.running) {
			try {
				if (this.thread != null) {
					Thread.sleep(this.sleepTime);
					synchronized (this) {
						while (this.threadSuspended){
							this.wait(); // sleeps until notify() wakes it up
						}
					}
				}
			} catch (InterruptedException e) {
				;
			}

			this.cycle(); // this represents 1 update cycle for the environment
		}
		this.thread = null;
	}

	/*
	 * This is the method attached to the "Start" button
	 */
	public synchronized void go() {
		if (this.thread == null) {
			this.thread = new Thread(this);
			this.running = true;
			this.thread.start();
			this.threadSuspended = false;
		} else {
			this.threadSuspended = false;
		}
		this.notify(); // wakes up the call to wait(), above
	}

	/*
	 * This is the method attached to the "Pause" button
	 */
	void pause() {
		if (this.thread == null){
			;
		}
		else{
			this.threadSuspended = true;
		}
	}

	/*
	 * This is a method called when you leave the page that contains the applet.
	 * It stops the thread altogether.
	 */
	public synchronized void stop() {
		this.running = false;
		this.notify();
	}

    /* end of the threading methods and of SpampedeBase */
}
