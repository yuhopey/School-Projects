#
# hw11pr2.py
#

import math
from visual import *

class Snitch:
    """ This class represents the player object...
    """

    def __repr__(self):
        """ The printable representation of an Alien """
        s = ''
        s += "This player is at "
        s += str( self.f.pos )
        s += " with vel = " + str( self.vel )
        return s

    # The constructor, named __init__ (as always in Python)
    def __init__(self, init_framepos):
        """ The constructor creates a frame (container)
            at initial location init_framepos
        """
        # a frame is VPython's collection of shapes
        # within a single coordinate system
        self.f = frame(pos=init_framepos)

        # the player's velocity
        self.vel = vector(0,0,0)

        # all of these parts are within the frame self.f
        self.body = sphere(pos=vector(0,0,0),
                           radius = 0.3, color=color.yellow,
                           frame=self.f)
        self.leftwing = ellipsoid(pos= self.body.pos + vector(-0.67,0.5,0),
                                  length=1.5,height=0.5,axis= (-0.5,0.5,0),width=0.2,
                                  color=color.yellow, right=(-2,2,2), frame=self.f)
        self.rightwing = ellipsoid(pos= self.body.pos + vector(0.67,0.5,0),
                                  length=1.5,height=0.5,axis= (0.5,0.5,0),width=0.2,
                                  color=color.yellow, right=(-2,2,2), frame=self.f)




