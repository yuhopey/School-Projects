#
# hw11pr1.py
#

import math
from visual import *
from random import choice
from finalplayer import *   # for the Alien class
from finalsnitch import *
from finalbludger import *


def collidex( self, collider):
        """ checks for a collision with the collider.
        """
        # mag is the magnitude of a vector, similar to abs for numbers     
        if self.f.pos.x > wallR.pos.x or self.f.pos.x < wallL.pos.x:
            return True  # collided
    


def main():
    """ This is the main function. It
        (1) creates the objects to show
        (2) runs an event loop allowing the user
            to move the objects and view around
    """
    
    field = box(pos = (0,-1,0),
            length = 100, width = 100, height = 0.1,
            color = (0.1,0.9,0.3))
    L= int(field.length )
    W= int(field.width)
    H = 50
    wallR = box(pos=(L/2,H/2-1,0), size= (0.1,L,W), visible= False)
    wallL = box(pos=(-L/2,H/2-1,0), size = (0.1,L,W), visible = False)
    wallB = box(pos=(0,H/2-1,-W/2), size= (W,L,0.1), visible = False)
    wallF = box(pos=(0,H/2-1,W/2), size = (W,L,0.1), visible = False)
    wallT = box(pos = (0,H-1,0),size=(L,0.1,W), visible = False)

    alien = Player( (0,0,0) )
    alien.vel = vector(0,0,0)
    
    #generate random starting positions
    startx = range(-L/2+2,L/2-2)
    starty = range(0,H-1)
    startz = range(-W/2+2,W/2+2)
    bludv = range(-20,20)
    snitchv = range(-50,50)

    snitch = Snitch ( (choice(startx),choice(starty),choice(startz)) )
    snitch.vel = vector(choice(snitchv),choice(snitchv),choice(snitchv))

    bludger1 = Bludger( (choice(startx),choice(starty),choice(startz)) )
    bludger1.vel = vector (choice(bludv),choice(bludv),choice(bludv))
    
    bludger2 = Bludger( (choice(startx),choice(starty),choice(startz)) )
    bludger2.vel =vector (choice(bludv),choice(bludv),choice(bludv))

    bludger3 = Bludger( (choice(startx),choice(starty),choice(startz)) )
    bludger3.vel = vector (choice(bludv),choice(bludv),choice(bludv))


   

    RATE = 100          # maximum update rate (in hertz)
    dt = 1.0/RATE       # time per loop
    scene.autoscale = False    # helpful for viewing

    loops = 0
   # the main simulation loop
    while True:
        loops = 1 + (loops % 1000)
        #resets the tongue to invisible every 1 second
        if loops%100 == 0 :
            alien.tongue.visible = False

        #flaps the snitch's wings    
        if loops%10 == 0:
            snitch.leftwing.axis = (-1.5,-1.5,0)
            snitch.leftwing.pos= snitch.body.pos + vector (-0.67, -0.5,0)
            snitch.rightwing.axis= (1.5,-1.5,0)
            snitch.rightwing.pos= snitch.body.pos + vector (0.67, -0.5,0)
        if loops%20 == 0 :
            snitch.leftwing.axis = (-1.5,1.5,0)
            snitch.leftwing.pos= snitch.body.pos + vector (-0.67, 0.5,0)
            snitch.rightwing.axis= (1.5,1.5,0)
            snitch.rightwing.pos= snitch.body.pos + vector (0.67, 0.5,0)
            

        #randomizes the velocity of the balls every 5 seconds
        if loops% 500 == 0:
            snitch.vel = vector(choice(snitchv),choice(snitchv),choice(snitchv))
            bludger1.vel = vector (choice(bludv),choice(bludv),choice(bludv))
            bludger2.vel = vector (choice(bludv),choice(bludv),choice(bludv))
            bludger3.vel = vector (choice(bludv),choice(bludv),choice(bludv))
            
            

        rate(RATE)  # this many times per second, at most
        #updates positions
        alien.f.pos += dt*alien.vel
        snitch.f.pos += dt*snitch.vel
        bludger1.f.pos += dt*bludger1.vel
        bludger2.f.pos += dt*bludger2.vel
        bludger3.f.pos += dt*bludger3.vel

        #list of things to check for collision
        col = [snitch, bludger1, bludger2, bludger3]
        colb = [bludger1, bludger2, bludger3]
        

        #checks to see if balls hit the invisible walls, if they do, they
        #bounce back so they always stay in the range of the field
        for i in range(len(col)):
            if col[i].f.pos.x > wallR.pos.x or col[i].f.pos.x < wallL.pos.x:
                col[i].vel.x = -col[i].vel.x 
            if col[i].f.pos.y > wallT.pos.y or col[i].f.pos.y -1 < field.pos.y:
                col[i].vel.y = -col[i].vel.y
            if col[i].f.pos.z > wallF.pos.z or col[i].f.pos.z < wallB.pos.z:
                col[i].vel.z = -col[i].vel.z

            

        #check for collison between player and bludger, if they collide the
        #player is reset to 0,0,0
        for j in range(len(colb)):
                if mag(colb[j].f.pos - alien.f.pos)< 2:
                        alien.f.pos = (0,0,0)

                        
        #checks for snitch collison, if there is one, you win!           
        if mag(snitch.f.pos - alien.f.pos)< 1:
                print 'You caught the Snitch!'
                alien.vel = vector(0,0,0)
                snitch.vel = vector(0,0,0)
                for k in range(len(colb)):
                        colb[k].vel = vector(0,0,0)


        #checks to see if alien collides with invisible wall, if he does
        # we make him stop so he doesn't go off the field
        if alien.f.pos.x > wallR.pos.x or alien.f.pos.x < wallL.pos.x:
                alien.vel.x = 0
        if alien.f.pos.y > wallT.pos.y or alien.f.pos.y -1 < field.pos.y:
                alien.vel.y = 0
        if alien.f.pos.z > wallF.pos.z or alien.f.pos.z < wallB.pos.z:
                alien.vel.z = 0

        if scene.mouse.clicked != 0: # is there a mouse click?
            #print "mouse click!"
            event = scene.mouse.getclick() # remove event
            scene.mouse.events = 0   # then reset mouse events
            
        if scene.kb.keys:            # is there a keyevent?
            s = scene.kb.getkey()    # get keypress
            #print "keypress is", s

            # move the alien around
            if s == "down":
                alien.vel.z += 2
                alien.f.axis = (0,0,-1)
            if s == "up":
                alien.vel.z += -2
                alien.f.axis = (0,0,1)
            if s == "left":
                alien.vel.x += -2
                alien.f.axis = (1,0,0)
            if s == "right":
                alien.vel.x += 2
                alien.f.axis = (-1,0,0)
            if s == " ":
                alien.f.pos += vector(0,1,0)
                falltime = 0
            if s == "h":
                alien.tongue.visible = True
            #the original purpose of the tongue was to add range, but
            #the precision is so low on this game that it really doesn't matter..
          
        #if alien is in the air and not ascending, then gravity!       
        if alien.f.pos.y > 0 :
            falltime += dt
            alien.vel.y = -9.8*falltime*falltime*1
            
        # check if alien hits the ground
        if alien.f.pos.y < 0:
            alien.vel.y = 0
            





if __name__ == "__main__":
    main()





