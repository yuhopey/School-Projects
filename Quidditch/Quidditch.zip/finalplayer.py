#
# hw11pr2.py
#

import math
from visual import *

class Player:
    """ This class represents the player object...
    """

    def __repr__(self):
        """ The printable representation of an Alien """
        s = ''
        s += "This player is at "
        s += str( self.f.pos )
        s += " with vel = " + str( self.vel )
        return s

    # The constructor, named __init__ (as always in Python)
    def __init__(self, init_framepos):
        """ The constructor creates a frame (container)
            at initial location init_framepos
        """
        # a frame is VPython's collection of shapes
        # within a single coordinate system
        self.f = frame(pos=init_framepos)

        # the player's velocity
        self.vel = vector(0,0,0)

        # all of these parts are within the frame self.f
        self.body = cone(pos=vector(0,0,0),
                           axis =(0,5,0),radius = 2, color=(0.7,0.5,0.5),
                           frame=self.f)
        
        self.head = sphere(pos=self.body.pos + vector(0,4.5,0),
                               radius=1.3,
                               color=color.white,
                               frame=self.f)
        self.tongue = ellipsoid(pos=self.head.pos + vector (-1.2,-0.4,0),
                                length=1.5, height =0.2, width= 0.5,
                                color=(0.7,0.2,0.3), frame=self.f)
        self.lefteye = sphere(pos=self.head.pos + vector(-0.8,0.4,-0.7),
                              radius = 0.2, color = color.black, frame=self.f)
        self.lefteye = sphere(pos=self.head.pos + vector(-0.8,0.4,0.7),
                            radius = 0.2, color = color.black, frame=self.f)
        
        self.broomend = sphere(pos=self.body.pos + vector(7,0.5,0),
                     radius =0.8, color = color.yellow , frame=self.f)
        self.broomendend = cone(pos=vector(8,0.5,0),
                           axis =(-2,0,0),radius = 1.2, color=color.yellow,
                           frame=self.f)
        self.broomstick = cylinder(pos=self.body.pos +vector(-3,0.5,0),axis=(10,0,0),
                              radius=0.2, color=(0.7,0.2,0.2), frame=self.f)
        #self.leftfoot = cylinder(pos=self.body.pos +vector(-1.5,-1,0),axis=(1,0.01,0),
                                  #radius=1, color=(0.7,0.2,0.2), frame=self.f)



